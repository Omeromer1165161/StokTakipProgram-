package Personel;

public class personelEkleme extends personelBilgileri{
    public personelEkleme(int Id, String ad, String soyad, String personelYeri){

        System.out.println("Personel Id : " + Id + "\nPersonel Ad :" + ad + "\nPersonel Soyad : " + soyad + "\nPersonel Çalışma Alanı : " + personelYeri);
    }
}

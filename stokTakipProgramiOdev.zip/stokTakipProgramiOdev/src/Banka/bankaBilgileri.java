package Banka;

public class bankaBilgileri {
         private final String[] iban = new String[1];
         public String bankaAdi;


    public String[] getiban(){
        return iban;
    }
}

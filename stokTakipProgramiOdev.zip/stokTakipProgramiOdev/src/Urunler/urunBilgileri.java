package Urunler;

public class urunBilgileri {
    private String barkodNo;
    private String urunAdi;
    public float urunFiyati;
    public int stokMiktari;
    public String urunAciklamasi;


    public String getBarkodNo(){
        return barkodNo;
    }
    public String geturunAdi(){
        return urunAdi;
    }
}

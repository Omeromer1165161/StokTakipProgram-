package Musteri;
public class musteriEkleme extends musteriBilgileri{

    public musteriEkleme(int Id, String ad, String soyad, String telefonNo){

        System.out.println("Müşteri Id : " + Id + "\nMüşteri Ad :" + ad + "\nMüşteri Soyad : " + soyad + "\nMüşteri Telefon No : " + telefonNo);
    }

}
